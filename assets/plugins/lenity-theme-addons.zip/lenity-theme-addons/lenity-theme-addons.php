<?php 
/*
Plugin Name:  Lenity Theme Addons
Plugin URI:   https://awaikenthemes.com
Description:  This plugin is intended for use with the lenity theme.
Version:      1.0.0
Author:       Awaiken Technology
Author URI:   https://awaiken.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  lenity-theme-addons
Domain Path:  /languages
*/

define( 'LENITY_ADDONS_URL', plugins_url( '/', __FILE__ ) );
define( 'LENITY_ADDONS_PATH', plugin_dir_path( __FILE__ ) );


// Load translation.
add_action( 'init', 'lenity_i18n' );

/**
 * Load the plugin text domain for translation.
 *
 * @since    1.0.0
 */
function lenity_i18n() {
	load_plugin_textdomain( 'lenity-theme-addons' );
}

/* Allow SVG upload */
add_filter( 'wp_check_filetype_and_ext', function( $data, $file, $filename, $mimes ) {

  $filetype = wp_check_filetype( $filename, $mimes );

  return [
      'ext' => $filetype['ext'],
      'type' => $filetype['type'],
      'proper_filename' => $data['proper_filename']
  ];

}, 10, 4 );

function lenity_allow_svg_upload( $mimes ) {
  $mimes['svg'] = 'image/svg+xml';
  $mimes['svgz'] = 'image/svg+xml';
  return $mimes;
}
add_filter( 'upload_mimes', 'lenity_allow_svg_upload' );

require LENITY_ADDONS_PATH . 'includes/secondary-image.php';


/*
* Project CPT
*/
if(!class_exists('Awaiken_Programmes')) { 
	class Awaiken_Programmes {

		const PROGRAMMES_CPT_SLUG = 'awaiken-programmes';
		const PROGRAMMES_CATEGORY_SLUG = 'awaiken-programmes-category';

		public function register_data() {

			$labels = [
				'name' => esc_html_x( 'Programmes', 'Programmes', 'lenity-theme-addons' ),
				'singular_name' => esc_html_x( 'Programmes', 'Programmes', 'lenity-theme-addons' ),
				'menu_name' => esc_html_x( 'Programmes', 'Programmes', 'lenity-theme-addons' ),
				'name_admin_bar' => esc_html__( 'Programmes Item', 'lenity-theme-addons' ),
				'archives' => esc_html__( 'Programmes Item Archives', 'lenity-theme-addons' ),
				'parent_item_colon' => esc_html__( 'Parent Item:', 'lenity-theme-addons' ),
				'all_items' => esc_html__( 'All Items', 'lenity-theme-addons' ),
				'add_new_item' => esc_html__( 'Add New Programmes', 'lenity-theme-addons' ),
				'add_new' => esc_html__( 'Add New', 'lenity-theme-addons' ),
				'new_item' => esc_html__( 'New Programmes', 'lenity-theme-addons' ),
				'edit_item' => esc_html__( 'Edit Programmes', 'lenity-theme-addons' ),
				'update_item' => esc_html__( 'Update Programmes', 'lenity-theme-addons' ),
				'view_item' => esc_html__( 'View Programmes', 'lenity-theme-addons' ),
				'search_items' => esc_html__( 'Search Programmes', 'lenity-theme-addons' ),
				'not_found' => esc_html__( 'Not found', 'lenity-theme-addons' ),
				'not_found_in_trash' => esc_html__( 'Not found in Trash', 'lenity-theme-addons' ),
				'featured_image' => esc_html__( 'Featured Image', 'lenity-theme-addons' ),
				'set_featured_image' => esc_html__( 'Set featured image', 'lenity-theme-addons' ),
				'remove_featured_image' => esc_html__( 'Remove featured image', 'lenity-theme-addons' ),
				'use_featured_image' => esc_html__( 'Use as featured image', 'lenity-theme-addons' ),
				'insert_into_item' => esc_html__( 'Insert into Programmes', 'lenity-theme-addons' ),
				'uploaded_to_this_item' => esc_html__( 'Uploaded to this Programmes', 'lenity-theme-addons' ),
				'items_list' => esc_html__( 'Items list', 'lenity-theme-addons' ),
				'items_list_navigation' => esc_html__( 'Items list navigation', 'lenity-theme-addons' ),
				'filter_items_list' => esc_html__( 'Filter items list', 'lenity-theme-addons' ),
			];

			$programmes_slug = apply_filters( 'awaiken_programmes_slug', 'programmes' );

			$rewrite = [
				'slug' => $programmes_slug,
				'with_front' => false,
			];

			$args = [
				'labels' => $labels,
				'public' => true,
				'menu_position' => 25,
				'menu_icon' => 'dashicons-format-image',
				'capability_type' => 'post',
				'supports' => [ 'title', 'editor', 'thumbnail', 'author', 'excerpt', 'comments', 'revisions', 'page-attributes', 'custom-fields', 'elementor' ],
				'has_archive' => true,
				'rewrite' => $rewrite,
			];

			register_post_type( self::PROGRAMMES_CPT_SLUG, $args );

			// Categories
			$programmes_category_slug = apply_filters( 'awaiken_programmes_category_slug', 'programmes-category' );

			$rewrite = [
				'slug' => $programmes_category_slug,
				'with_front' => false,
			];

			$args = [
				'hierarchical' => true,
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'show_admin_column' => true,
				'labels' => $labels,
				'rewrite' => $rewrite,
				'public' => true,
				'labels' => [
					'name' => esc_html_x( 'Categories', 'Programmes', 'lenity-theme-addons' ),
					'singular_name' => esc_html_x( 'Category', 'Programmes', 'lenity-theme-addons' ),
					'all_items' => esc_html_x( 'All Categories', 'Programmes', 'lenity-theme-addons' ),
				],
			];
			register_taxonomy( self::PROGRAMMES_CATEGORY_SLUG, self::PROGRAMMES_CPT_SLUG, $args );
		}

		public function __construct() {
			add_action( 'init', [ $this, 'register_data' ], 1 );
		}
	}
	/**
	 * initialize 
	 */
	$Awaiken_Programmes = new Awaiken_Programmes();
}